const fs = require("fs");

// ==== CARREGAR ARQUIVO env (SEM PONTO) ====
if (fs.existsSync("env")) {
    const variables = fs.readFileSync("env", "utf8").split("\n");
    for (let line of variables) {
        line = line.trim();
        if (!line || line.startsWith("#")) continue;

        const [key, value] = line.split("=");
        if (key && value) process.env[key.trim()] = value.trim();
    }
}

const { 
    Client, 
    GatewayIntentBits,
    Partials,
    Routes,
    REST,
    SlashCommandBuilder,
    PermissionFlagsBits,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle
} = require("discord.js");

const TOKEN = process.env.TOKEN;
const BOT_ID = process.env.BOT_ID;
const EMBED_ROLE = process.env.EMBED_ROLE;

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages
    ],
    partials: [Partials.Channel]
});

client.once("ready", () => {
    console.log(`Bot online como: ${client.user.tag}`);
});

/* -----------------------------------------
   REGISTRO DO COMANDO /embed-create
------------------------------------------ */

const commands = [
    new SlashCommandBuilder()
        .setName("embed-create")
        .setDescription("Cria um embed personalizado")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .toJSON()
];

const rest = new REST({ version: "10" }).setToken(TOKEN);

(async () => {
    try {
        console.log("Registrando slash commands...");
        await rest.put(
            Routes.applicationCommands(BOT_ID),
            { body: commands }
        );
        console.log("Slash commands registrados com sucesso!");
    } catch (e) {
        console.log("Erro ao registrar comandos:", e);
    }
})();

/* -----------------------------------------
   SISTEMA DO /embed-create
------------------------------------------ */

client.on("interactionCreate", async interaction => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === "embed-create") {
        if (!interaction.member.roles.cache.has(EMBED_ROLE)) {
            return interaction.reply({
                content: "❌ Você não tem permissão para usar este comando.",
                ephemeral: true
            });
        }

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("add_title")
                .setLabel("Adicionar Título")
                .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
                .setCustomId("add_description")
                .setLabel("Adicionar Descrição")
                .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
                .setCustomId("add_color")
                .setLabel("Definir Cor")
                .setStyle(ButtonStyle.Secondary),

            new ButtonBuilder()
                .setCustomId("add_image")
                .setLabel("Enviar Imagem/Vídeo (5s)")
                .setStyle(ButtonStyle.Secondary)
        );

        interaction.reply({
            content: "🎨 **Painel de criação de Embed**",
            components: [row],
            ephemeral: true
        });
    }
});

/* -----------------------------------------
   BOTÕES
------------------------------------------ */

client.on("interactionCreate", async interaction => {
    if (!interaction.isButton()) return;

    const modal = new ModalBuilder();

    if (interaction.customId === "add_title") {
        modal.setCustomId("modal_title").setTitle("Título do Embed");

        modal.addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("embed_title")
                    .setLabel("Título do embed")
                    .setStyle(TextInputStyle.Short)
                    .setRequired(true)
            )
        );

        return interaction.showModal(modal);
    }

    if (interaction.customId === "add_description") {
        modal.setCustomId("modal_description").setTitle("Descrição do Embed");

        modal.addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId("embed_description")
                    .setLabel("Descrição")
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true)
            )
        );

        return interaction.showModal(modal);
    }
});

/* -----------------------------------------
   MODAIS
------------------------------------------ */

client.on("interactionCreate", async interaction => {
    if (!interaction.isModalSubmit()) return;

    if (interaction.customId === "modal_title") {
        const title = interaction.fields.getTextInputValue("embed_title");

        const embed = new EmbedBuilder()
            .setTitle(title)
            .setColor("#2b2d31");

        return interaction.reply({ embeds: [embed], ephemeral: false });
    }

    if (interaction.customId === "modal_description") {
        const description = interaction.fields.getTextInputValue("embed_description");

        const embed = new EmbedBuilder()
            .setDescription(description)
            .setColor("#2b2d31");

        return interaction.reply({ embeds: [embed], ephemeral: false });
    }
});

client.login(TOKEN);